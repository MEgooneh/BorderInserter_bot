<?php
class config{
    public $host;
    public $database;
    public $users;
    public $passes;
    function __construct(){
	    $this->host='localhost';
	    $this->database='atarix_channel';
	    $this->users='root';
	    $this->passes='';
    }//END METHOD
}//END CLASS
?>