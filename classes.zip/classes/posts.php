<?php
// COLLATE utf8_persian_ci ==> Baraye namayesh Sahih Sort Horofe Farsi 'گ چ پ ژ'
date_default_timezone_set("asia/tehran");
require_once 'sql.class.php';

class POSTS{
	
	private $sql;
	
	function __construct()
	{
		$this->sql=new SQL(); 
	}
	
	public function addNewPost($post_id){ //
		
		$cs="SELECT post_id FROM posts
			WHERE post_id = '".$post_id."'";
		$chk_usr = $this->sql->QueryWithResult($cs);
		
		if(!$chk_usr){
			$cs="INSERT INTO posts SET
				post_id = '".$post_id."'";

			return $this->sql->QueryWithNoResult($cs);
		}

	}
	
	public function getPost($post_id){ //
		$cs="SELECT * FROM posts
			WHERE post_id ='".$post_id."'";
		
		return $this->sql->QueryWithResult($cs);
	}	
	
	public function checkPostUser($post_id, $user_id){ //
		
		$cs="SELECT * FROM user_post
			WHERE post_id = '".$post_id."'
			AND user_id = '".$user_id."'";
		return $this->sql->QueryWithResult($cs);

	}
	
	public function addNewPostUser($post_id, $user_id, $vote){ //
		
			$cs="INSERT INTO user_post SET
				post_id = '".$post_id."',
				user_id = '".$user_id."',
				date = '".date('Y-m-d')."',
				time = '".date('H:i:s')."',
				vote = '".$vote."'";

			return $this->sql->QueryWithNoResult($cs);

	}	
	
	
	public function updatePost($post_id, $user_id, $vote_type){
		
		$chk_vote = $this->checkPostUser($post_id, $user_id); 
		
		if(count($chk_vote) > 0){ //if exist
			
			$user_vote = $chk_vote[0]->vote;
			
			if($user_vote == $vote_type){
				return 'repeated_vote';
			}else{
				if($vote_type == 'up'){
					
					$cs="UPDATE posts SET
						like_count = like_count+1,
						unlike_count = unlike_count-1
						WHERE post_id='".$post_id."'";
					$this->sql->QueryWithNoResult($cs);	
					
				}elseif($vote_type == 'down'){
					$cs="UPDATE posts SET
						like_count = like_count-1,
						unlike_count = unlike_count+1
						WHERE post_id='".$post_id."'";
					$this->sql->QueryWithNoResult($cs);						
				}
				
				$cs="UPDATE user_post SET
					vote = '".$vote_type."'
					WHERE post_id = '".$post_id."'
					AND user_id = '".$user_id."'";
				$this->sql->QueryWithNoResult($cs);
				
				return 'updated_vote';
			}
			
		}else{
			
			$this->addNewPostUser($post_id, $user_id, $vote_type);
			
			if($vote_type == 'up')
				$cs="UPDATE posts SET
					like_count = like_count+1
					WHERE post_id = '".$post_id."'";

			if($vote_type == 'down')
				$cs="UPDATE posts SET
					unlike_count = unlike_count+1
					WHERE post_id = '".$post_id."'";

			$this->sql->QueryWithNoResult($cs);
			
			return 'registered_vote';
		}
		
	}		
	
}
?>