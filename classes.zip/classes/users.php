<?php
// COLLATE utf8_persian_ci ==> Baraye namayesh Sahih Sort Horofe Farsi 'گ چ پ ژ'
date_default_timezone_set("asia/tehran");
require_once 'sql.class.php';

class USERS{
	
	private $sql;
	
	function __construct()
	{
		$this->sql=new SQL(); 
	}
	
	public function addNewUser($user_id, $username, $name, $family, $join_type){ //
		
		$cs="SELECT user_id FROM users
			WHERE user_id = '".$user_id."'";
		$chk_usr= $this->sql->QueryWithResult($cs);
		
		if(count($chk_usr)==0){
			$cs="INSERT INTO users SET
				user_id   = '".$user_id."',
				username  = '".$username."',
				name	  = '".$name."',
				family	  = '".$family."',
				join_type = '".$join_type."',
				join_date = '".date('Y-m-d')."',
				join_time = '".date('H:i:s')."'";

			return $this->sql->QueryWithNoResult($cs);
		}

	}
	
	public function updateFieldByChatId($user_id, $field, $cmd){ //
			$cs="UPDATE users SET
				".$field." = '".$cmd."'
				WHERE user_id='".$user_id."'";

			return $this->sql->QueryWithNoResult($cs);
	}
	
	public function updateViewCount($tone_codes, $operator){ //
		$cs="UPDATE ".$operator." 
			SET view = view + 1 
			WHERE code IN (".$tone_codes.")";

		return $this->sql->QueryWithNoResult($cs);
	}
	
	public function updateUserInvitePoint($invited_user_id, $inviter_code){ // INVITE POINT

		$cs="SELECT invited_user_id FROM user_invite
			WHERE invited_user_id = '".$invited_user_id."'";
			
		$chk_usr= $this->sql->QueryWithResult($cs);
		
		if(!$chk_usr){ // agar ghablan davat nashode bashad emtiaz ezafe kon
			
			$cs="INSERT INTO user_invite SET
				inviter_user_id   = '".$inviter_code."',
				invited_user_id   = '".$invited_user_id."',
				join_date = '".date('Y-m-d')."',
				join_time = '".date('H:i:s')."'";

			$add = $this->sql->QueryWithNoResult($cs);
			
			if($add){
				$cs="UPDATE users 
				SET invite_point = invite_point + 1 
				WHERE user_id = '".$inviter_code."'";

				return $this->sql->QueryWithNoResult($cs);
			}
		}
	}

}
?>