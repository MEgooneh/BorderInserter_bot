<?php
//SECURITY FUNCTIONS
require_once("config.php");
class DB{
	
    private $connect;
    private $config;
	
    function __construct(){
    	$this->conf=new config();
		$this->connect_db();
	}

    function connect_db(){
		//procedural style
		//$mysqli =  mysqli_connect('host','username','password','database_name');
		
		//object oriented style (recommended)
		$this->connect = new mysqli($this->conf->host,$this->conf->users,$this->conf->passes, $this->conf->database);
		
		//Output any connection error
		if ($this->connect->connect_error) {
			die('Cant Access to DB! :('. $mysqli->connect_errno .') '. $mysqli->connect_error);
		} else return $this->connect;
		
    }
}

function strip_html_tags( $input ){
    $input = preg_replace(
        array(
          // Remove invisible content
            '@<head[^>]*?>.*?</head>@siu',
            '@<style[^>]*?>.*?</style>@siu',
            '@<script[^>]*?.*?</script>@siu',
            '@<object[^>]*?.*?</object>@siu',
            '@<embed[^>]*?.*?</embed>@siu',
            '@<applet[^>]*?.*?</applet>@siu',
            '@<noframes[^>]*?.*?</noframes>@siu',
            '@<noscript[^>]*?.*?</noscript>@siu',
            '@<noembed[^>]*?.*?</noembed>@siu'
        ),
        array(
            '', '', '', '', '', '', '', '', ''), $input );
      
    return strip_tags( $input);
}

function make_safe($variable) {
	
	$db_ptr = new DB(); // create instance
	
    $variable = strip_html_tags($variable);
	$bad = array("=","<", ">", "/","\"","`","~","'","$","%","#");
	$variable = str_replace($bad, "", $variable);
    $variable = mysqli_real_escape_string($db_ptr->connect_db(),trim($variable));
    return $variable;
}

function URLmake_safe($variable) {
	
	$db_ptr = new DB(); // create instance
	
    $variable = strip_html_tags($variable);
	$bad = array("=","<", ">","\"","`","~","'","$","%","#");
	$variable = str_replace($bad, "", $variable);
     $variable = mysqli_real_escape_string($db_ptr->connect_db(),trim($variable));
    return $variable;
}

function pNumber($string) {
    $persian = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹');
    $eng = range(0, 9);
    return str_replace($eng, $persian, $string);
}

function persianFormatNum ($string){
	$pnum = number_format($string);
	return pNumber($pnum);
}

function dateTimeDifference($dt1, $dt2){ // ekhtelaf tarikh be tafkik mah rooz saat daghighe sanie
	$date1 = new DateTime($dt1);
	$date2 = new DateTime($dt2);
	$res = $date1->diff($date2);
//var_dump($res);
	$txt = '';
	if($res->m > 0) $txt.= $res->m.' ماه';
	if($res->m > 0 && $res->d > 0) $txt.=' و ';
	
	if($res->d > 0) $txt.= $res->d.' روز';
	if($res->d > 0 && $res->h > 0) $txt.=' و ';
	
	if($res->h > 0) $txt.= $res->h.' ساعت';
	
	if($res->i > 0 && ($res->m > 0 || $res->d > 0 || $res->h > 0)) $txt.=' و ';
	if($res->i > 0) $txt.= $res->i.' دقیقه';
	
	if($res->m > 0 && $res->d > 0) $txt= ($res->m * 30) + $res->d .' روز';
	
	if($res->m == 0 && $res->d == 0 && $res->h == 0 && $res->i == 0 && $res->s > 0) $txt = $res->s.' ثانیه';
	
	return $txt; echo $res;
}

?>