<?php
require_once("config.php");

class SQL{
    private $conn;
    private $conf;
    function __construct(){
    	$this->conf=new config();
		$this->connect();
	}

    function connect(){
		//procedural style
		//$mysqli =  mysqli_connect('host','username','password','database_name');
		
		//object oriented style (recommended)
		$this->conn = new mysqli($this->conf->host,$this->conf->users,$this->conf->passes, $this->conf->database);
		
		//Output any connection error
		if ($this->conn->connect_error) {
			die('Cant Access to DB! :('. $mysqli->connect_errno .') '. $mysqli->connect_error);
		}
		
    }
	
	function QueryWithNoResult($string){
		
		 if($this->conn)
		    @mysqli_close($this->conn);
		$this->connect();
		//mysqli_query($string) or die(mysql_error());
		//return true;
		@mysqli_query($this->conn,"SET NAMES 'utf8'");
		if(@mysqli_query($this->conn, $string))
			return true;
		die(mysqli_error($this->conn).'<br /> Error in Runing Query With No Result!');
	}
	
	function QueryWithResult($string){
		if($this->conn)
		    @mysqli_close($this->conn);
		$this->connect();
//		$result=mysql_query($string) or die(mysql_error());
		@mysqli_query($this->conn,"SET NAMES 'utf8'");
		$result=mysqli_query($this->conn, $string) or die("خطا در دسترسي به بانك -  جدول - اطلاعاتي".'<br />'.$string);
		
		$arr=array();
		while($row=mysqli_fetch_object($result)){
			array_push($arr,$row);
		}
		// Frees the memory associated with a result
		$result->free();
		
		return $arr;
	}

	function query($string){
		if($this->conn)
		    @mysqli_close($this->conn);
		$this->connect();
		return mysqli_query($this->conn, $string);
	}
	
    function __destruct(){
        if($this->conn)
		    @mysqli_close($this->conn);
	}
}
//END CLASS
?>