<?php

namespace Intervention\Image\Exception;

class ImageException extends \RuntimeException
{
    # nothing to override
}
